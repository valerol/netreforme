<? 
	$page = $_GET['page']; 
	Header ( "Location: $page" ); 
	exit(); 
?> 
